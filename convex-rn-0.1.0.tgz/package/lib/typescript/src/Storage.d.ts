export interface Storage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
    clear(): void;
}
export declare const syncStorage: Storage;
//# sourceMappingURL=Storage.d.ts.map