export interface DatabaseChange {
    type: 'insert' | 'update' | 'delete';
    table: string;
    id: string;
    indexableText?: string[];
    jsonData?: string;
    updatedAt?: number;
}
export interface DataDelta {
    sequenceNumber: number;
    timestamp: number;
    changes: DatabaseChange[];
}
export type IndexRuleFunction = (doc: any, getCachedItem: (table: string, id: string) => any) => string[];
export interface SyncEngineOptions {
    backgroundMode?: boolean;
    schemaMap: Record<string, {
        table: string;
    }>;
    indexRules?: Record<string, IndexRuleFunction>;
}
export interface QueuedMutation {
    queueId: string;
    tableName: string;
    mutationPath: string;
    docId: string;
    localFields: Record<string, any>;
    mutationArgs: Record<string, any>;
    timestamp: number;
}
export declare class ConvexSyncEngine {
    private backgroundMode;
    private schemaMap;
    private indexRules;
    private sequenceNumber;
    private isProcessingQueue;
    private isOnline;
    private convexClient;
    private convexHttpClient;
    private unsubscribeConnection;
    private activeQueries;
    constructor(convexUrl: string, options: SyncEngineOptions);
    /**
     * Listens to Convex WebSocket connection events to trigger flushes on network recovery.
     */
    private initializeConnectionListener;
    /**
     * Helper to retrieve a document from cache for relational indexing/joins
     */
    getCachedItem: (table: string, id: string) => any;
    /**
     * Synchronous query retrieval for React Native UI
     */
    getCachedQueryResults(queryPath: string, args?: Record<string, any>): any[];
    /**
     * Registers a UI listener for a query and handles background synchronization.
     * Returns an unsubscribe function.
     */
    subscribeQuery(queryPath: string, args: Record<string, any> | undefined, onChange: () => void): () => void;
    /**
     * Trigger callback notifies to React hooks
     */
    private notifyListeners;
    /**
     * Synchronizes a specific query parameter set.
     * Compares fresh query results with cached results, runs indexing, and pushes generic delta natively.
     */
    syncQuery(queryPath: string, args?: Record<string, any>): Promise<any[]>;
    /**
     * Handles query result changes by diffing, updating local cache, and piping deltas to Native bridge.
     */
    private handleQueryResultUpdate;
    /**
     * Helper to merge fresh query results into the global table database
     */
    private mergeFreshIntoGlobal;
    /**
     * Performs local optimistic update, queues backend mutation in local storage,
     * updates native models, and attempts to send writes eventually.
     */
    performMutation(tableName: string, mutationPath: string, id: string, localFields: Record<string, any>, mutationArgs: Record<string, any>): Promise<void>;
    /**
     * Processes the queue of mutations sequentially, keeping order (FIFO).
     */
    processMutationQueue(): Promise<void>;
    private pipeDeltaToNative;
    /**
     * Closes the underlying Convex WebSocket client connection and cleans up listeners.
     */
    close(): void;
}
/**
 * Custom React Hook that returns local cached values instantly (synchronously),
 * binds UI updates dynamically, and triggers auto-sync in the background.
 */
export declare function useSyncQuery<T = any>(syncEngine: ConvexSyncEngine, queryPath: string, args?: Record<string, any>): T[];
//# sourceMappingURL=ConvexSyncEngine.d.ts.map