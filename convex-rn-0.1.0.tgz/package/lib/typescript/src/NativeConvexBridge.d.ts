import { type TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    applyDelta(jsonString: string): Promise<boolean>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeConvexBridge.d.ts.map